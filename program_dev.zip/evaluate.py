#!/usr/bin/env python
import sys, os, os.path

import subprocess
import re

from sacrebleu.metrics import BLEU, CHRF, TER

# Run nvidia-smi command to check if the GPU is working
os.system('nvidia-smi')

input_dir = sys.argv[1]
output_dir = sys.argv[2]

submit_dir = os.path.join(input_dir, 'res') 
truth_dir = os.path.join(input_dir, 'ref')

if not os.path.isdir(submit_dir):
	print("%s doesn't exist" % submit_dir)

if os.path.isdir(submit_dir) and os.path.isdir(truth_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    output_filename = os.path.join(output_dir, 'scores.txt')              
    output_file = open(output_filename, 'w')
    
    
    truth_file = os.path.join(truth_dir, "tatoeba.test.esp")
    truth = open(truth_file).read()

    source_file = os.path.join(truth_dir, "tatoeba.test.guc")
    source = open(source_file).read()

    submission_answer_file = os.path.join(submit_dir, "tatoeba.test.guc2esp.esp")
    submission_answer = open(submission_answer_file).read()
    
    bleu = BLEU()
    chrf = CHRF()
    ter = TER()

    res = bleu.corpus_score(submission_answer.split('\n'), [truth.split('\n')]) 
    #valueBLEU = re.search(r'\(μ = (.*?) \)',str(res)).group(1)
    valueBLEU = re.search(r'BLEU = (.*?) ',str(res)).group(1)
    output_file.write("BLEU: %2.2f\n" % float(valueBLEU))

    # CHRF calculation
    res = chrf.corpus_score(submission_answer.split('\n'), [truth.split('\n')])
    valueCHRF = re.search(r'chrF2 =(.*)',str(res)).group(1)
    output_file.write("chrF: %2.2f\n" % float(valueCHRF))

    # TER calculation
    res = ter.corpus_score(submission_answer.split('\n'), [truth.split('\n')])
    valueTER = re.search(r'TER =(.*)',str(res)).group(1)
    output_file.write("TER: %2.2f\n" % float(valueTER))

    # COMET calculation
    cmd = ['comet-score', '-s', source_file, '-t', submission_answer_file, '-r' , truth_file, '--gpus', '0']
    result = subprocess.run(cmd, stdout=subprocess.PIPE)
    valueCOMET = re.search(r'score: (0.\d\d\d\d)',str(result.stdout)).group(1)
    output_file.write("COMET: %0.4f\n" % float(valueCOMET))

    output_file.close()
